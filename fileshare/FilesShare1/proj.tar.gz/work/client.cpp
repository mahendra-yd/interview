#include "tcpsocket.h"
using namespace std;

void ReadInput();
int main()
{

ReadInput();
return 0;
} 

